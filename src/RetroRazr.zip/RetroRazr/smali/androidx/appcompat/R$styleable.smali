.class public final Landroidx/appcompat/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final ActionBar:[I

.field public static final ActionBarLayout:[I

.field public static final ActionBarLayout_android_layout_gravity:I = 0x0

.field public static final ActionBar_background:I = 0x0

.field public static final ActionBar_backgroundSplit:I = 0x1

.field public static final ActionBar_backgroundStacked:I = 0x2

.field public static final ActionBar_contentInsetEnd:I = 0x3

.field public static final ActionBar_contentInsetEndWithActions:I = 0x4

.field public static final ActionBar_contentInsetLeft:I = 0x5

.field public static final ActionBar_contentInsetRight:I = 0x6

.field public static final ActionBar_contentInsetStart:I = 0x7

.field public static final ActionBar_contentInsetStartWithNavigation:I = 0x8

.field public static final ActionBar_customNavigationLayout:I = 0x9

.field public static final ActionBar_displayOptions:I = 0xa

.field public static final ActionBar_divider:I = 0xb

.field public static final ActionBar_elevation:I = 0xc

.field public static final ActionBar_height:I = 0xd

.field public static final ActionBar_hideOnContentScroll:I = 0xe

.field public static final ActionBar_homeAsUpIndicator:I = 0xf

.field public static final ActionBar_homeLayout:I = 0x10

.field public static final ActionBar_icon:I = 0x11

.field public static final ActionBar_indeterminateProgressStyle:I = 0x12

.field public static final ActionBar_itemPadding:I = 0x13

.field public static final ActionBar_logo:I = 0x14

.field public static final ActionBar_navigationMode:I = 0x15

.field public static final ActionBar_popupTheme:I = 0x16

.field public static final ActionBar_progressBarPadding:I = 0x17

.field public static final ActionBar_progressBarStyle:I = 0x18

.field public static final ActionBar_subtitle:I = 0x19

.field public static final ActionBar_subtitleTextStyle:I = 0x1a

.field public static final ActionBar_title:I = 0x1b

.field public static final ActionBar_titleTextStyle:I = 0x1c

.field public static final ActionMenuItemView:[I

.field public static final ActionMenuItemView_android_minWidth:I = 0x0

.field public static final ActionMenuView:[I

.field public static final ActionMode:[I

.field public static final ActionMode_background:I = 0x0

.field public static final ActionMode_backgroundSplit:I = 0x1

.field public static final ActionMode_closeItemLayout:I = 0x2

.field public static final ActionMode_height:I = 0x3

.field public static final ActionMode_subtitleTextStyle:I = 0x4

.field public static final ActionMode_titleTextStyle:I = 0x5

.field public static final ActivityChooserView:[I

.field public static final ActivityChooserView_expandActivityOverflowButtonDrawable:I = 0x0

.field public static final ActivityChooserView_initialActivityCount:I = 0x1

.field public static final AlertDialog:[I

.field public static final AlertDialog_android_layout:I = 0x0

.field public static final AlertDialog_buttonIconDimen:I = 0x1

.field public static final AlertDialog_buttonPanelSideLayout:I = 0x2

.field public static final AlertDialog_listItemLayout:I = 0x3

.field public static final AlertDialog_listLayout:I = 0x4

.field public static final AlertDialog_multiChoiceItemLayout:I = 0x5

.field public static final AlertDialog_showTitle:I = 0x6

.field public static final AlertDialog_singleChoiceItemLayout:I = 0x7

.field public static final AnimatedStateListDrawableCompat:[I

.field public static final AnimatedStateListDrawableCompat_android_constantSize:I = 0x3

.field public static final AnimatedStateListDrawableCompat_android_dither:I = 0x0

.field public static final AnimatedStateListDrawableCompat_android_enterFadeDuration:I = 0x4

.field public static final AnimatedStateListDrawableCompat_android_exitFadeDuration:I = 0x5

.field public static final AnimatedStateListDrawableCompat_android_variablePadding:I = 0x2

.field public static final AnimatedStateListDrawableCompat_android_visible:I = 0x1

.field public static final AnimatedStateListDrawableItem:[I

.field public static final AnimatedStateListDrawableItem_android_drawable:I = 0x1

.field public static final AnimatedStateListDrawableItem_android_id:I = 0x0

.field public static final AnimatedStateListDrawableTransition:[I

.field public static final AnimatedStateListDrawableTransition_android_drawable:I = 0x0

.field public static final AnimatedStateListDrawableTransition_android_fromId:I = 0x2

.field public static final AnimatedStateListDrawableTransition_android_reversible:I = 0x3

.field public static final AnimatedStateListDrawableTransition_android_toId:I = 0x1

.field public static final AppCompatImageView:[I

.field public static final AppCompatImageView_android_src:I = 0x0

.field public static final AppCompatImageView_srcCompat:I = 0x1

.field public static final AppCompatImageView_tint:I = 0x2

.field public static final AppCompatImageView_tintMode:I = 0x3

.field public static final AppCompatSeekBar:[I

.field public static final AppCompatSeekBar_android_thumb:I = 0x0

.field public static final AppCompatSeekBar_tickMark:I = 0x1

.field public static final AppCompatSeekBar_tickMarkTint:I = 0x2

.field public static final AppCompatSeekBar_tickMarkTintMode:I = 0x3

.field public static final AppCompatTextHelper:[I

.field public static final AppCompatTextHelper_android_drawableBottom:I = 0x2

.field public static final AppCompatTextHelper_android_drawableEnd:I = 0x6

.field public static final AppCompatTextHelper_android_drawableLeft:I = 0x3

.field public static final AppCompatTextHelper_android_drawableRight:I = 0x4

.field public static final AppCompatTextHelper_android_drawableStart:I = 0x5

.field public static final AppCompatTextHelper_android_drawableTop:I = 0x1

.field public static final AppCompatTextHelper_android_textAppearance:I = 0x0

.field public static final AppCompatTextView:[I

.field public static final AppCompatTextView_android_textAppearance:I = 0x0

.field public static final AppCompatTextView_autoSizeMaxTextSize:I = 0x1

.field public static final AppCompatTextView_autoSizeMinTextSize:I = 0x2

.field public static final AppCompatTextView_autoSizePresetSizes:I = 0x3

.field public static final AppCompatTextView_autoSizeStepGranularity:I = 0x4

.field public static final AppCompatTextView_autoSizeTextType:I = 0x5

.field public static final AppCompatTextView_firstBaselineToTopHeight:I = 0x6

.field public static final AppCompatTextView_fontFamily:I = 0x7

.field public static final AppCompatTextView_lastBaselineToBottomHeight:I = 0x8

.field public static final AppCompatTextView_lineHeight:I = 0x9

.field public static final AppCompatTextView_textAllCaps:I = 0xa

.field public static final AppCompatTheme:[I

.field public static final AppCompatTheme_actionBarDivider:I = 0x2

.field public static final AppCompatTheme_actionBarItemBackground:I = 0x3

.field public static final AppCompatTheme_actionBarPopupTheme:I = 0x4

.field public static final AppCompatTheme_actionBarSize:I = 0x5

.field public static final AppCompatTheme_actionBarSplitStyle:I = 0x6

.field public static final AppCompatTheme_actionBarStyle:I = 0x7

.field public static final AppCompatTheme_actionBarTabBarStyle:I = 0x8

.field public static final AppCompatTheme_actionBarTabStyle:I = 0x9

.field public static final AppCompatTheme_actionBarTabTextStyle:I = 0xa

.field public static final AppCompatTheme_actionBarTheme:I = 0xb

.field public static final AppCompatTheme_actionBarWidgetTheme:I = 0xc

.field public static final AppCompatTheme_actionButtonStyle:I = 0xd

.field public static final AppCompatTheme_actionDropDownStyle:I = 0xe

.field public static final AppCompatTheme_actionMenuTextAppearance:I = 0xf

.field public static final AppCompatTheme_actionMenuTextColor:I = 0x10

.field public static final AppCompatTheme_actionModeBackground:I = 0x11

.field public static final AppCompatTheme_actionModeCloseButtonStyle:I = 0x12

.field public static final AppCompatTheme_actionModeCloseDrawable:I = 0x13

.field public static final AppCompatTheme_actionModeCopyDrawable:I = 0x14

.field public static final AppCompatTheme_actionModeCutDrawable:I = 0x15

.field public static final AppCompatTheme_actionModeFindDrawable:I = 0x16

.field public static final AppCompatTheme_actionModePasteDrawable:I = 0x17

.field public static final AppCompatTheme_actionModePopupWindowStyle:I = 0x18

.field public static final AppCompatTheme_actionModeSelectAllDrawable:I = 0x19

.field public static final AppCompatTheme_actionModeShareDrawable:I = 0x1a

.field public static final AppCompatTheme_actionModeSplitBackground:I = 0x1b

.field public static final AppCompatTheme_actionModeStyle:I = 0x1c

.field public static final AppCompatTheme_actionModeWebSearchDrawable:I = 0x1d

.field public static final AppCompatTheme_actionOverflowButtonStyle:I = 0x1e

.field public static final AppCompatTheme_actionOverflowMenuStyle:I = 0x1f

.field public static final AppCompatTheme_activityChooserViewStyle:I = 0x20

.field public static final AppCompatTheme_alertDialogButtonGroupStyle:I = 0x21

.field public static final AppCompatTheme_alertDialogCenterButtons:I = 0x22

.field public static final AppCompatTheme_alertDialogStyle:I = 0x23

.field public static final AppCompatTheme_alertDialogTheme:I = 0x24

.field public static final AppCompatTheme_android_windowAnimationStyle:I = 0x1

.field public static final AppCompatTheme_android_windowIsFloating:I = 0x0

.field public static final AppCompatTheme_autoCompleteTextViewStyle:I = 0x25

.field public static final AppCompatTheme_borderlessButtonStyle:I = 0x26

.field public static final AppCompatTheme_buttonBarButtonStyle:I = 0x27

.field public static final AppCompatTheme_buttonBarNegativeButtonStyle:I = 0x28

.field public static final AppCompatTheme_buttonBarNeutralButtonStyle:I = 0x29

.field public static final AppCompatTheme_buttonBarPositiveButtonStyle:I = 0x2a

.field public static final AppCompatTheme_buttonBarStyle:I = 0x2b

.field public static final AppCompatTheme_buttonStyle:I = 0x2c

.field public static final AppCompatTheme_buttonStyleSmall:I = 0x2d

.field public static final AppCompatTheme_checkboxStyle:I = 0x2e

.field public static final AppCompatTheme_checkedTextViewStyle:I = 0x2f

.field public static final AppCompatTheme_colorAccent:I = 0x30

.field public static final AppCompatTheme_colorBackgroundFloating:I = 0x31

.field public static final AppCompatTheme_colorButtonNormal:I = 0x32

.field public static final AppCompatTheme_colorControlActivated:I = 0x33

.field public static final AppCompatTheme_colorControlHighlight:I = 0x34

.field public static final AppCompatTheme_colorControlNormal:I = 0x35

.field public static final AppCompatTheme_colorError:I = 0x36

.field public static final AppCompatTheme_colorPrimary:I = 0x37

.field public static final AppCompatTheme_colorPrimaryDark:I = 0x38

.field public static final AppCompatTheme_colorSwitchThumbNormal:I = 0x39

.field public static final AppCompatTheme_controlBackground:I = 0x3a

.field public static final AppCompatTheme_dialogCornerRadius:I = 0x3b

.field public static final AppCompatTheme_dialogPreferredPadding:I = 0x3c

.field public static final AppCompatTheme_dialogTheme:I = 0x3d

.field public static final AppCompatTheme_dividerHorizontal:I = 0x3e

.field public static final AppCompatTheme_dividerVertical:I = 0x3f

.field public static final AppCompatTheme_dropDownListViewStyle:I = 0x40

.field public static final AppCompatTheme_dropdownListPreferredItemHeight:I = 0x41

.field public static final AppCompatTheme_editTextBackground:I = 0x42

.field public static final AppCompatTheme_editTextColor:I = 0x43

.field public static final AppCompatTheme_editTextStyle:I = 0x44

.field public static final AppCompatTheme_homeAsUpIndicator:I = 0x45

.field public static final AppCompatTheme_imageButtonStyle:I = 0x46

.field public static final AppCompatTheme_listChoiceBackgroundIndicator:I = 0x47

.field public static final AppCompatTheme_listDividerAlertDialog:I = 0x48

.field public static final AppCompatTheme_listMenuViewStyle:I = 0x49

.field public static final AppCompatTheme_listPopupWindowStyle:I = 0x4a

.field public static final AppCompatTheme_listPreferredItemHeight:I = 0x4b

.field public static final AppCompatTheme_listPreferredItemHeightLarge:I = 0x4c

.field public static final AppCompatTheme_listPreferredItemHeightSmall:I = 0x4d

.field public static final AppCompatTheme_listPreferredItemPaddingLeft:I = 0x4e

.field public static final AppCompatTheme_listPreferredItemPaddingRight:I = 0x4f

.field public static final AppCompatTheme_panelBackground:I = 0x50

.field public static final AppCompatTheme_panelMenuListTheme:I = 0x51

.field public static final AppCompatTheme_panelMenuListWidth:I = 0x52

.field public static final AppCompatTheme_popupMenuStyle:I = 0x53

.field public static final AppCompatTheme_popupWindowStyle:I = 0x54

.field public static final AppCompatTheme_radioButtonStyle:I = 0x55

.field public static final AppCompatTheme_ratingBarStyle:I = 0x56

.field public static final AppCompatTheme_ratingBarStyleIndicator:I = 0x57

.field public static final AppCompatTheme_ratingBarStyleSmall:I = 0x58

.field public static final AppCompatTheme_searchViewStyle:I = 0x59

.field public static final AppCompatTheme_seekBarStyle:I = 0x5a

.field public static final AppCompatTheme_selectableItemBackground:I = 0x5b

.field public static final AppCompatTheme_selectableItemBackgroundBorderless:I = 0x5c

.field public static final AppCompatTheme_spinnerDropDownItemStyle:I = 0x5d

.field public static final AppCompatTheme_spinnerStyle:I = 0x5e

.field public static final AppCompatTheme_switchStyle:I = 0x5f

.field public static final AppCompatTheme_textAppearanceLargePopupMenu:I = 0x60

.field public static final AppCompatTheme_textAppearanceListItem:I = 0x61

.field public static final AppCompatTheme_textAppearanceListItemSecondary:I = 0x62

.field public static final AppCompatTheme_textAppearanceListItemSmall:I = 0x63

.field public static final AppCompatTheme_textAppearancePopupMenuHeader:I = 0x64

.field public static final AppCompatTheme_textAppearanceSearchResultSubtitle:I = 0x65

.field public static final AppCompatTheme_textAppearanceSearchResultTitle:I = 0x66

.field public static final AppCompatTheme_textAppearanceSmallPopupMenu:I = 0x67

.field public static final AppCompatTheme_textColorAlertDialogListItem:I = 0x68

.field public static final AppCompatTheme_textColorSearchUrl:I = 0x69

.field public static final AppCompatTheme_toolbarNavigationButtonStyle:I = 0x6a

.field public static final AppCompatTheme_toolbarStyle:I = 0x6b

.field public static final AppCompatTheme_tooltipForegroundColor:I = 0x6c

.field public static final AppCompatTheme_tooltipFrameBackground:I = 0x6d

.field public static final AppCompatTheme_viewInflaterClass:I = 0x6e

.field public static final AppCompatTheme_windowActionBar:I = 0x6f

.field public static final AppCompatTheme_windowActionBarOverlay:I = 0x70

.field public static final AppCompatTheme_windowActionModeOverlay:I = 0x71

.field public static final AppCompatTheme_windowFixedHeightMajor:I = 0x72

.field public static final AppCompatTheme_windowFixedHeightMinor:I = 0x73

.field public static final AppCompatTheme_windowFixedWidthMajor:I = 0x74

.field public static final AppCompatTheme_windowFixedWidthMinor:I = 0x75

.field public static final AppCompatTheme_windowMinWidthMajor:I = 0x76

.field public static final AppCompatTheme_windowMinWidthMinor:I = 0x77

.field public static final AppCompatTheme_windowNoTitle:I = 0x78

.field public static final ButtonBarLayout:[I

.field public static final ButtonBarLayout_allowStacking:I = 0x0

.field public static final ColorStateListItem:[I

.field public static final ColorStateListItem_alpha:I = 0x2

.field public static final ColorStateListItem_android_alpha:I = 0x1

.field public static final ColorStateListItem_android_color:I = 0x0

.field public static final CompoundButton:[I

.field public static final CompoundButton_android_button:I = 0x0

.field public static final CompoundButton_buttonTint:I = 0x1

.field public static final CompoundButton_buttonTintMode:I = 0x2

.field public static final CoordinatorLayout:[I

.field public static final CoordinatorLayout_Layout:[I

.field public static final CoordinatorLayout_Layout_android_layout_gravity:I = 0x0

.field public static final CoordinatorLayout_Layout_layout_anchor:I = 0x1

.field public static final CoordinatorLayout_Layout_layout_anchorGravity:I = 0x2

.field public static final CoordinatorLayout_Layout_layout_behavior:I = 0x3

.field public static final CoordinatorLayout_Layout_layout_dodgeInsetEdges:I = 0x4

.field public static final CoordinatorLayout_Layout_layout_insetEdge:I = 0x5

.field public static final CoordinatorLayout_Layout_layout_keyline:I = 0x6

.field public static final CoordinatorLayout_keylines:I = 0x0

.field public static final CoordinatorLayout_statusBarBackground:I = 0x1

.field public static final DrawerArrowToggle:[I

.field public static final DrawerArrowToggle_arrowHeadLength:I = 0x0

.field public static final DrawerArrowToggle_arrowShaftLength:I = 0x1

.field public static final DrawerArrowToggle_barLength:I = 0x2

.field public static final DrawerArrowToggle_color:I = 0x3

.field public static final DrawerArrowToggle_drawableSize:I = 0x4

.field public static final DrawerArrowToggle_gapBetweenBars:I = 0x5

.field public static final DrawerArrowToggle_spinBars:I = 0x6

.field public static final DrawerArrowToggle_thickness:I = 0x7

.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static final FontFamilyFont_android_font:I = 0x0

.field public static final FontFamilyFont_android_fontStyle:I = 0x2

.field public static final FontFamilyFont_android_fontVariationSettings:I = 0x4

.field public static final FontFamilyFont_android_fontWeight:I = 0x1

.field public static final FontFamilyFont_android_ttcIndex:I = 0x3

.field public static final FontFamilyFont_font:I = 0x5

.field public static final FontFamilyFont_fontStyle:I = 0x6

.field public static final FontFamilyFont_fontVariationSettings:I = 0x7

.field public static final FontFamilyFont_fontWeight:I = 0x8

.field public static final FontFamilyFont_ttcIndex:I = 0x9

.field public static final FontFamily_fontProviderAuthority:I = 0x0

.field public static final FontFamily_fontProviderCerts:I = 0x1

.field public static final FontFamily_fontProviderFetchStrategy:I = 0x2

.field public static final FontFamily_fontProviderFetchTimeout:I = 0x3

.field public static final FontFamily_fontProviderPackage:I = 0x4

.field public static final FontFamily_fontProviderQuery:I = 0x5

.field public static final GradientColor:[I

.field public static final GradientColorItem:[I

.field public static final GradientColorItem_android_color:I = 0x0

.field public static final GradientColorItem_android_offset:I = 0x1

.field public static final GradientColor_android_centerColor:I = 0x7

.field public static final GradientColor_android_centerX:I = 0x3

.field public static final GradientColor_android_centerY:I = 0x4

.field public static final GradientColor_android_endColor:I = 0x1

.field public static final GradientColor_android_endX:I = 0xa

.field public static final GradientColor_android_endY:I = 0xb

.field public static final GradientColor_android_gradientRadius:I = 0x5

.field public static final GradientColor_android_startColor:I = 0x0

.field public static final GradientColor_android_startX:I = 0x8

.field public static final GradientColor_android_startY:I = 0x9

.field public static final GradientColor_android_tileMode:I = 0x6

.field public static final GradientColor_android_type:I = 0x2

.field public static final LinearLayoutCompat:[I

.field public static final LinearLayoutCompat_Layout:[I

.field public static final LinearLayoutCompat_Layout_android_layout_gravity:I = 0x0

.field public static final LinearLayoutCompat_Layout_android_layout_height:I = 0x2

.field public static final LinearLayoutCompat_Layout_android_layout_weight:I = 0x3

.field public static final LinearLayoutCompat_Layout_android_layout_width:I = 0x1

.field public static final LinearLayoutCompat_android_baselineAligned:I = 0x2

.field public static final LinearLayoutCompat_android_baselineAlignedChildIndex:I = 0x3

.field public static final LinearLayoutCompat_android_gravity:I = 0x0

.field public static final LinearLayoutCompat_android_orientation:I = 0x1

.field public static final LinearLayoutCompat_android_weightSum:I = 0x4

.field public static final LinearLayoutCompat_divider:I = 0x5

.field public static final LinearLayoutCompat_dividerPadding:I = 0x6

.field public static final LinearLayoutCompat_measureWithLargestChild:I = 0x7

.field public static final LinearLayoutCompat_showDividers:I = 0x8

.field public static final ListPopupWindow:[I

.field public static final ListPopupWindow_android_dropDownHorizontalOffset:I = 0x0

.field public static final ListPopupWindow_android_dropDownVerticalOffset:I = 0x1

.field public static final MenuGroup:[I

.field public static final MenuGroup_android_checkableBehavior:I = 0x5

.field public static final MenuGroup_android_enabled:I = 0x0

.field public static final MenuGroup_android_id:I = 0x1

.field public static final MenuGroup_android_menuCategory:I = 0x3

.field public static final MenuGroup_android_orderInCategory:I = 0x4

.field public static final MenuGroup_android_visible:I = 0x2

.field public static final MenuItem:[I

.field public static final MenuItem_actionLayout:I = 0xd

.field public static final MenuItem_actionProviderClass:I = 0xe

.field public static final MenuItem_actionViewClass:I = 0xf

.field public static final MenuItem_alphabeticModifiers:I = 0x10

.field public static final MenuItem_android_alphabeticShortcut:I = 0x9

.field public static final MenuItem_android_checkable:I = 0xb

.field public static final MenuItem_android_checked:I = 0x3

.field public static final MenuItem_android_enabled:I = 0x1

.field public static final MenuItem_android_icon:I = 0x0

.field public static final MenuItem_android_id:I = 0x2

.field public static final MenuItem_android_menuCategory:I = 0x5

.field public static final MenuItem_android_numericShortcut:I = 0xa

.field public static final MenuItem_android_onClick:I = 0xc

.field public static final MenuItem_android_orderInCategory:I = 0x6

.field public static final MenuItem_android_title:I = 0x7

.field public static final MenuItem_android_titleCondensed:I = 0x8

.field public static final MenuItem_android_visible:I = 0x4

.field public static final MenuItem_contentDescription:I = 0x11

.field public static final MenuItem_iconTint:I = 0x12

.field public static final MenuItem_iconTintMode:I = 0x13

.field public static final MenuItem_numericModifiers:I = 0x14

.field public static final MenuItem_showAsAction:I = 0x15

.field public static final MenuItem_tooltipText:I = 0x16

.field public static final MenuView:[I

.field public static final MenuView_android_headerBackground:I = 0x4

.field public static final MenuView_android_horizontalDivider:I = 0x2

.field public static final MenuView_android_itemBackground:I = 0x5

.field public static final MenuView_android_itemIconDisabledAlpha:I = 0x6

.field public static final MenuView_android_itemTextAppearance:I = 0x1

.field public static final MenuView_android_verticalDivider:I = 0x3

.field public static final MenuView_android_windowAnimationStyle:I = 0x0

.field public static final MenuView_preserveIconSpacing:I = 0x7

.field public static final MenuView_subMenuArrow:I = 0x8

.field public static final PopupWindow:[I

.field public static final PopupWindowBackgroundState:[I

.field public static final PopupWindowBackgroundState_state_above_anchor:I = 0x0

.field public static final PopupWindow_android_popupAnimationStyle:I = 0x1

.field public static final PopupWindow_android_popupBackground:I = 0x0

.field public static final PopupWindow_overlapAnchor:I = 0x2

.field public static final RecycleListView:[I

.field public static final RecycleListView_paddingBottomNoButtons:I = 0x0

.field public static final RecycleListView_paddingTopNoTitle:I = 0x1

.field public static final SearchView:[I

.field public static final SearchView_android_focusable:I = 0x0

.field public static final SearchView_android_imeOptions:I = 0x3

.field public static final SearchView_android_inputType:I = 0x2

.field public static final SearchView_android_maxWidth:I = 0x1

.field public static final SearchView_closeIcon:I = 0x4

.field public static final SearchView_commitIcon:I = 0x5

.field public static final SearchView_defaultQueryHint:I = 0x6

.field public static final SearchView_goIcon:I = 0x7

.field public static final SearchView_iconifiedByDefault:I = 0x8

.field public static final SearchView_layout:I = 0x9

.field public static final SearchView_queryBackground:I = 0xa

.field public static final SearchView_queryHint:I = 0xb

.field public static final SearchView_searchHintIcon:I = 0xc

.field public static final SearchView_searchIcon:I = 0xd

.field public static final SearchView_submitBackground:I = 0xe

.field public static final SearchView_suggestionRowLayout:I = 0xf

.field public static final SearchView_voiceIcon:I = 0x10

.field public static final Spinner:[I

.field public static final Spinner_android_dropDownWidth:I = 0x3

.field public static final Spinner_android_entries:I = 0x0

.field public static final Spinner_android_popupBackground:I = 0x1

.field public static final Spinner_android_prompt:I = 0x2

.field public static final Spinner_popupTheme:I = 0x4

.field public static final StateListDrawable:[I

.field public static final StateListDrawableItem:[I

.field public static final StateListDrawableItem_android_drawable:I = 0x0

.field public static final StateListDrawable_android_constantSize:I = 0x3

.field public static final StateListDrawable_android_dither:I = 0x0

.field public static final StateListDrawable_android_enterFadeDuration:I = 0x4

.field public static final StateListDrawable_android_exitFadeDuration:I = 0x5

.field public static final StateListDrawable_android_variablePadding:I = 0x2

.field public static final StateListDrawable_android_visible:I = 0x1

.field public static final SwitchCompat:[I

.field public static final SwitchCompat_android_textOff:I = 0x1

.field public static final SwitchCompat_android_textOn:I = 0x0

.field public static final SwitchCompat_android_thumb:I = 0x2

.field public static final SwitchCompat_showText:I = 0x3

.field public static final SwitchCompat_splitTrack:I = 0x4

.field public static final SwitchCompat_switchMinWidth:I = 0x5

.field public static final SwitchCompat_switchPadding:I = 0x6

.field public static final SwitchCompat_switchTextAppearance:I = 0x7

.field public static final SwitchCompat_thumbTextPadding:I = 0x8

.field public static final SwitchCompat_thumbTint:I = 0x9

.field public static final SwitchCompat_thumbTintMode:I = 0xa

.field public static final SwitchCompat_track:I = 0xb

.field public static final SwitchCompat_trackTint:I = 0xc

.field public static final SwitchCompat_trackTintMode:I = 0xd

.field public static final TextAppearance:[I

.field public static final TextAppearance_android_fontFamily:I = 0xa

.field public static final TextAppearance_android_shadowColor:I = 0x6

.field public static final TextAppearance_android_shadowDx:I = 0x7

.field public static final TextAppearance_android_shadowDy:I = 0x8

.field public static final TextAppearance_android_shadowRadius:I = 0x9

.field public static final TextAppearance_android_textColor:I = 0x3

.field public static final TextAppearance_android_textColorHint:I = 0x4

.field public static final TextAppearance_android_textColorLink:I = 0x5

.field public static final TextAppearance_android_textSize:I = 0x0

.field public static final TextAppearance_android_textStyle:I = 0x2

.field public static final TextAppearance_android_typeface:I = 0x1

.field public static final TextAppearance_fontFamily:I = 0xb

.field public static final TextAppearance_textAllCaps:I = 0xc

.field public static final Toolbar:[I

.field public static final Toolbar_android_gravity:I = 0x0

.field public static final Toolbar_android_minHeight:I = 0x1

.field public static final Toolbar_buttonGravity:I = 0x2

.field public static final Toolbar_collapseContentDescription:I = 0x3

.field public static final Toolbar_collapseIcon:I = 0x4

.field public static final Toolbar_contentInsetEnd:I = 0x5

.field public static final Toolbar_contentInsetEndWithActions:I = 0x6

.field public static final Toolbar_contentInsetLeft:I = 0x7

.field public static final Toolbar_contentInsetRight:I = 0x8

.field public static final Toolbar_contentInsetStart:I = 0x9

.field public static final Toolbar_contentInsetStartWithNavigation:I = 0xa

.field public static final Toolbar_logo:I = 0xb

.field public static final Toolbar_logoDescription:I = 0xc

.field public static final Toolbar_maxButtonHeight:I = 0xd

.field public static final Toolbar_navigationContentDescription:I = 0xe

.field public static final Toolbar_navigationIcon:I = 0xf

.field public static final Toolbar_popupTheme:I = 0x10

.field public static final Toolbar_subtitle:I = 0x11

.field public static final Toolbar_subtitleTextAppearance:I = 0x12

.field public static final Toolbar_subtitleTextColor:I = 0x13

.field public static final Toolbar_title:I = 0x14

.field public static final Toolbar_titleMargin:I = 0x15

.field public static final Toolbar_titleMarginBottom:I = 0x16

.field public static final Toolbar_titleMarginEnd:I = 0x17

.field public static final Toolbar_titleMarginStart:I = 0x18

.field public static final Toolbar_titleMarginTop:I = 0x19

.field public static final Toolbar_titleMargins:I = 0x1a

.field public static final Toolbar_titleTextAppearance:I = 0x1b

.field public static final Toolbar_titleTextColor:I = 0x1c

.field public static final View:[I

.field public static final ViewBackgroundHelper:[I

.field public static final ViewBackgroundHelper_android_background:I = 0x0

.field public static final ViewBackgroundHelper_backgroundTint:I = 0x1

.field public static final ViewBackgroundHelper_backgroundTintMode:I = 0x2

.field public static final ViewStubCompat:[I

.field public static final ViewStubCompat_android_id:I = 0x0

.field public static final ViewStubCompat_android_inflatedId:I = 0x2

.field public static final ViewStubCompat_android_layout:I = 0x1

.field public static final View_android_focusable:I = 0x1

.field public static final View_android_theme:I = 0x0

.field public static final View_paddingEnd:I = 0x2

.field public static final View_paddingStart:I = 0x3

.field public static final View_theme:I = 0x4


# direct methods
.method public static constructor <clinit>()V
    .locals 10

    const/16 v0, 0x1d

    new-array v1, v0, [I

    fill-array-data v1, :array_0

    sput-object v1, Landroidx/appcompat/R$styleable;->ActionBar:[I

    const/4 v1, 0x1

    new-array v2, v1, [I

    const v3, 0x10100b3

    const/4 v4, 0x0

    aput v3, v2, v4

    sput-object v2, Landroidx/appcompat/R$styleable;->ActionBarLayout:[I

    new-array v2, v1, [I

    const v3, 0x101013f

    aput v3, v2, v4

    sput-object v2, Landroidx/appcompat/R$styleable;->ActionMenuItemView:[I

    new-array v2, v4, [I

    sput-object v2, Landroidx/appcompat/R$styleable;->ActionMenuView:[I

    const/4 v2, 0x6

    new-array v3, v2, [I

    fill-array-data v3, :array_1

    sput-object v3, Landroidx/appcompat/R$styleable;->ActionMode:[I

    const/4 v3, 0x2

    new-array v5, v3, [I

    fill-array-data v5, :array_2

    sput-object v5, Landroidx/appcompat/R$styleable;->ActivityChooserView:[I

    const/16 v5, 0x8

    new-array v6, v5, [I

    fill-array-data v6, :array_3

    sput-object v6, Landroidx/appcompat/R$styleable;->AlertDialog:[I

    new-array v6, v2, [I

    fill-array-data v6, :array_4

    sput-object v6, Landroidx/appcompat/R$styleable;->AnimatedStateListDrawableCompat:[I

    new-array v6, v3, [I

    fill-array-data v6, :array_5

    sput-object v6, Landroidx/appcompat/R$styleable;->AnimatedStateListDrawableItem:[I

    const/4 v6, 0x4

    new-array v7, v6, [I

    fill-array-data v7, :array_6

    sput-object v7, Landroidx/appcompat/R$styleable;->AnimatedStateListDrawableTransition:[I

    new-array v7, v6, [I

    fill-array-data v7, :array_7

    sput-object v7, Landroidx/appcompat/R$styleable;->AppCompatImageView:[I

    new-array v7, v6, [I

    fill-array-data v7, :array_8

    sput-object v7, Landroidx/appcompat/R$styleable;->AppCompatSeekBar:[I

    const/4 v7, 0x7

    new-array v8, v7, [I

    fill-array-data v8, :array_9

    sput-object v8, Landroidx/appcompat/R$styleable;->AppCompatTextHelper:[I

    const/16 v8, 0xb

    new-array v8, v8, [I

    fill-array-data v8, :array_a

    sput-object v8, Landroidx/appcompat/R$styleable;->AppCompatTextView:[I

    const/16 v8, 0x79

    new-array v8, v8, [I

    fill-array-data v8, :array_b

    sput-object v8, Landroidx/appcompat/R$styleable;->AppCompatTheme:[I

    new-array v8, v1, [I

    const v9, 0x7f040026

    aput v9, v8, v4

    sput-object v8, Landroidx/appcompat/R$styleable;->ButtonBarLayout:[I

    const/4 v8, 0x3

    new-array v9, v8, [I

    fill-array-data v9, :array_c

    sput-object v9, Landroidx/appcompat/R$styleable;->ColorStateListItem:[I

    new-array v9, v8, [I

    fill-array-data v9, :array_d

    sput-object v9, Landroidx/appcompat/R$styleable;->CompoundButton:[I

    new-array v9, v3, [I

    fill-array-data v9, :array_e

    sput-object v9, Landroidx/appcompat/R$styleable;->CoordinatorLayout:[I

    new-array v7, v7, [I

    fill-array-data v7, :array_f

    sput-object v7, Landroidx/appcompat/R$styleable;->CoordinatorLayout_Layout:[I

    new-array v5, v5, [I

    fill-array-data v5, :array_10

    sput-object v5, Landroidx/appcompat/R$styleable;->DrawerArrowToggle:[I

    new-array v5, v2, [I

    fill-array-data v5, :array_11

    sput-object v5, Landroidx/appcompat/R$styleable;->FontFamily:[I

    const/16 v5, 0xa

    new-array v5, v5, [I

    fill-array-data v5, :array_12

    sput-object v5, Landroidx/appcompat/R$styleable;->FontFamilyFont:[I

    const/16 v5, 0xc

    new-array v5, v5, [I

    fill-array-data v5, :array_13

    sput-object v5, Landroidx/appcompat/R$styleable;->GradientColor:[I

    new-array v5, v3, [I

    fill-array-data v5, :array_14

    sput-object v5, Landroidx/appcompat/R$styleable;->GradientColorItem:[I

    const/16 v5, 0x9

    new-array v7, v5, [I

    fill-array-data v7, :array_15

    sput-object v7, Landroidx/appcompat/R$styleable;->LinearLayoutCompat:[I

    new-array v6, v6, [I

    fill-array-data v6, :array_16

    sput-object v6, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_Layout:[I

    new-array v6, v3, [I

    fill-array-data v6, :array_17

    sput-object v6, Landroidx/appcompat/R$styleable;->ListPopupWindow:[I

    new-array v6, v2, [I

    fill-array-data v6, :array_18

    sput-object v6, Landroidx/appcompat/R$styleable;->MenuGroup:[I

    const/16 v6, 0x17

    new-array v6, v6, [I

    fill-array-data v6, :array_19

    sput-object v6, Landroidx/appcompat/R$styleable;->MenuItem:[I

    new-array v5, v5, [I

    fill-array-data v5, :array_1a

    sput-object v5, Landroidx/appcompat/R$styleable;->MenuView:[I

    new-array v5, v8, [I

    fill-array-data v5, :array_1b

    sput-object v5, Landroidx/appcompat/R$styleable;->PopupWindow:[I

    new-array v5, v1, [I

    const v6, 0x7f0401a1

    aput v6, v5, v4

    sput-object v5, Landroidx/appcompat/R$styleable;->PopupWindowBackgroundState:[I

    new-array v3, v3, [I

    fill-array-data v3, :array_1c

    sput-object v3, Landroidx/appcompat/R$styleable;->RecycleListView:[I

    const/16 v3, 0x11

    new-array v3, v3, [I

    fill-array-data v3, :array_1d

    sput-object v3, Landroidx/appcompat/R$styleable;->SearchView:[I

    const/4 v3, 0x5

    new-array v5, v3, [I

    fill-array-data v5, :array_1e

    sput-object v5, Landroidx/appcompat/R$styleable;->Spinner:[I

    new-array v2, v2, [I

    fill-array-data v2, :array_1f

    sput-object v2, Landroidx/appcompat/R$styleable;->StateListDrawable:[I

    new-array v1, v1, [I

    const v2, 0x1010199

    aput v2, v1, v4

    sput-object v1, Landroidx/appcompat/R$styleable;->StateListDrawableItem:[I

    const/16 v1, 0xe

    new-array v1, v1, [I

    fill-array-data v1, :array_20

    sput-object v1, Landroidx/appcompat/R$styleable;->SwitchCompat:[I

    const/16 v1, 0xd

    new-array v1, v1, [I

    fill-array-data v1, :array_21

    sput-object v1, Landroidx/appcompat/R$styleable;->TextAppearance:[I

    new-array v0, v0, [I

    fill-array-data v0, :array_22

    sput-object v0, Landroidx/appcompat/R$styleable;->Toolbar:[I

    new-array v0, v3, [I

    fill-array-data v0, :array_23

    sput-object v0, Landroidx/appcompat/R$styleable;->View:[I

    new-array v0, v8, [I

    fill-array-data v0, :array_24

    sput-object v0, Landroidx/appcompat/R$styleable;->ViewBackgroundHelper:[I

    new-array v0, v8, [I

    fill-array-data v0, :array_25

    sput-object v0, Landroidx/appcompat/R$styleable;->ViewStubCompat:[I

    return-void

    :array_0
    .array-data 4
        0x7f040031
        0x7f040032
        0x7f040033
        0x7f040097
        0x7f040098
        0x7f040099
        0x7f04009a
        0x7f04009b
        0x7f04009c
        0x7f0400aa
        0x7f0400af
        0x7f0400b0
        0x7f0400bb
        0x7f0400e6
        0x7f0400eb
        0x7f0400f0
        0x7f0400f1
        0x7f0400f3
        0x7f0400fd
        0x7f040107
        0x7f04015c
        0x7f040168
        0x7f040179
        0x7f04017d
        0x7f04017e
        0x7f0401b0
        0x7f0401b3
        0x7f0401f9
        0x7f040203
    .end array-data

    :array_1
    .array-data 4
        0x7f040031
        0x7f040032
        0x7f040081
        0x7f0400e6
        0x7f0401b3
        0x7f040203
    .end array-data

    :array_2
    .array-data 4
        0x7f0400c1
        0x7f0400fe
    .end array-data

    :array_3
    .array-data 4
        0x10100f2
        0x7f040054
        0x7f040055
        0x7f040153
        0x7f040154
        0x7f040165
        0x7f040194
        0x7f040195
    .end array-data

    :array_4
    .array-data 4
        0x101011c
        0x1010194
        0x1010195
        0x1010196
        0x101030c
        0x101030d
    .end array-data

    :array_5
    .array-data 4
        0x10100d0
        0x1010199
    .end array-data

    :array_6
    .array-data 4
        0x1010199
        0x1010449
        0x101044a
        0x101044b
    .end array-data

    :array_7
    .array-data 4
        0x1010119
        0x7f04019f
        0x7f0401f7
        0x7f0401f8
    .end array-data

    :array_8
    .array-data 4
        0x1010142
        0x7f0401f4
        0x7f0401f5
        0x7f0401f6
    .end array-data

    :array_9
    .array-data 4
        0x1010034
        0x101016d
        0x101016e
        0x101016f
        0x1010170
        0x1010392
        0x1010393
    .end array-data

    :array_a
    .array-data 4
        0x1010034
        0x7f04002c
        0x7f04002d
        0x7f04002e
        0x7f04002f
        0x7f040030
        0x7f0400d5
        0x7f0400d8
        0x7f04010f
        0x7f04014f
        0x7f0401d3
    .end array-data

    :array_b
    .array-data 4
        0x1010057
        0x10100ae
        0x7f040000
        0x7f040001
        0x7f040002
        0x7f040003
        0x7f040004
        0x7f040005
        0x7f040006
        0x7f040007
        0x7f040008
        0x7f040009
        0x7f04000a
        0x7f04000b
        0x7f04000c
        0x7f04000e
        0x7f04000f
        0x7f040010
        0x7f040011
        0x7f040012
        0x7f040013
        0x7f040014
        0x7f040015
        0x7f040016
        0x7f040017
        0x7f040018
        0x7f040019
        0x7f04001a
        0x7f04001b
        0x7f04001c
        0x7f04001d
        0x7f04001e
        0x7f040021
        0x7f040022
        0x7f040023
        0x7f040024
        0x7f040025
        0x7f04002b
        0x7f040040
        0x7f04004e
        0x7f04004f
        0x7f040050
        0x7f040051
        0x7f040052
        0x7f040056
        0x7f040057
        0x7f040062
        0x7f040067
        0x7f040087
        0x7f040088
        0x7f040089
        0x7f04008a
        0x7f04008b
        0x7f04008c
        0x7f04008d
        0x7f04008e
        0x7f04008f
        0x7f040091
        0x7f0400a3
        0x7f0400ac
        0x7f0400ad
        0x7f0400ae
        0x7f0400b1
        0x7f0400b3
        0x7f0400b6
        0x7f0400b7
        0x7f0400b8
        0x7f0400b9
        0x7f0400ba
        0x7f0400f0
        0x7f0400fc
        0x7f040151
        0x7f040152
        0x7f040155
        0x7f040156
        0x7f040157
        0x7f040158
        0x7f040159
        0x7f04015a
        0x7f04015b
        0x7f040170
        0x7f040171
        0x7f040172
        0x7f040178
        0x7f04017a
        0x7f040181
        0x7f040182
        0x7f040183
        0x7f040184
        0x7f04018c
        0x7f04018d
        0x7f04018e
        0x7f04018f
        0x7f04019c
        0x7f04019d
        0x7f0401b7
        0x7f0401de
        0x7f0401df
        0x7f0401e0
        0x7f0401e1
        0x7f0401e3
        0x7f0401e4
        0x7f0401e5
        0x7f0401e6
        0x7f0401e9
        0x7f0401ea
        0x7f040205
        0x7f040206
        0x7f040207
        0x7f040208
        0x7f04020f
        0x7f040211
        0x7f040212
        0x7f040213
        0x7f040214
        0x7f040215
        0x7f040216
        0x7f040217
        0x7f040218
        0x7f040219
        0x7f04021a
    .end array-data

    :array_c
    .array-data 4
        0x10101a5
        0x101031f
        0x7f040027
    .end array-data

    :array_d
    .array-data 4
        0x1010107
        0x7f040058
        0x7f040059
    .end array-data

    :array_e
    .array-data 4
        0x7f04010d
        0x7f0401aa
    .end array-data

    :array_f
    .array-data 4
        0x10100b3
        0x7f040112
        0x7f040113
        0x7f040114
        0x7f040140
        0x7f040149
        0x7f04014a
    .end array-data

    :array_10
    .array-data 4
        0x7f040029
        0x7f04002a
        0x7f040036
        0x7f040086
        0x7f0400b4
        0x7f0400e3
        0x7f04019b
        0x7f0401f0
    .end array-data

    :array_11
    .array-data 4
        0x7f0400d9
        0x7f0400da
        0x7f0400db
        0x7f0400dc
        0x7f0400dd
        0x7f0400de
    .end array-data

    :array_12
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f0400d7
        0x7f0400df
        0x7f0400e0
        0x7f0400e1
        0x7f04020d
    .end array-data

    :array_13
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data

    :array_14
    .array-data 4
        0x10101a5
        0x1010514
    .end array-data

    :array_15
    .array-data 4
        0x10100af
        0x10100c4
        0x1010126
        0x1010127
        0x1010128
        0x7f0400b0
        0x7f0400b2
        0x7f040163
        0x7f040191
    .end array-data

    :array_16
    .array-data 4
        0x10100b3
        0x10100f4
        0x10100f5
        0x1010181
    .end array-data

    :array_17
    .array-data 4
        0x10102ac
        0x10102ad
    .end array-data

    :array_18
    .array-data 4
        0x101000e
        0x10100d0
        0x1010194
        0x10101de
        0x10101df
        0x10101e0
    .end array-data

    :array_19
    .array-data 4
        0x1010002
        0x101000e
        0x10100d0
        0x1010106
        0x1010194
        0x10101de
        0x10101df
        0x10101e1
        0x10101e2
        0x10101e3
        0x10101e4
        0x10101e5
        0x101026f
        0x7f04000d
        0x7f04001f
        0x7f040020
        0x7f040028
        0x7f040096
        0x7f0400f9
        0x7f0400fa
        0x7f04016a
        0x7f040190
        0x7f040209
    .end array-data

    :array_1a
    .array-data 4
        0x10100ae
        0x101012c
        0x101012d
        0x101012e
        0x101012f
        0x1010130
        0x1010131
        0x7f04017b
        0x7f0401ae
    .end array-data

    :array_1b
    .array-data 4
        0x1010176
        0x10102c9
        0x7f04016b
    .end array-data

    :array_1c
    .array-data 4
        0x7f04016c
        0x7f04016f
    .end array-data

    :array_1d
    .array-data 4
        0x10100da
        0x101011f
        0x1010220
        0x1010264
        0x7f04007a
        0x7f040092
        0x7f0400ab
        0x7f0400e4
        0x7f0400fb
        0x7f040110
        0x7f04017f
        0x7f040180
        0x7f04018a
        0x7f04018b
        0x7f0401af
        0x7f0401b4
        0x7f040210
    .end array-data

    :array_1e
    .array-data 4
        0x10100b2
        0x1010176
        0x101017b
        0x1010262
        0x7f040179
    .end array-data

    :array_1f
    .array-data 4
        0x101011c
        0x1010194
        0x1010195
        0x1010196
        0x101030c
        0x101030d
    .end array-data

    :array_20
    .array-data 4
        0x1010124
        0x1010125
        0x1010142
        0x7f040193
        0x7f04019e
        0x7f0401b5
        0x7f0401b6
        0x7f0401b8
        0x7f0401f1
        0x7f0401f2
        0x7f0401f3
        0x7f04020a
        0x7f04020b
        0x7f04020c
    .end array-data

    :array_21
    .array-data 4
        0x1010095
        0x1010096
        0x1010097
        0x1010098
        0x101009a
        0x101009b
        0x1010161
        0x1010162
        0x1010163
        0x1010164
        0x10103ac
        0x7f0400d8
        0x7f0401d3
    .end array-data

    :array_22
    .array-data 4
        0x10100af
        0x1010140
        0x7f040053
        0x7f040082
        0x7f040083
        0x7f040097
        0x7f040098
        0x7f040099
        0x7f04009a
        0x7f04009b
        0x7f04009c
        0x7f04015c
        0x7f04015d
        0x7f040161
        0x7f040166
        0x7f040167
        0x7f040179
        0x7f0401b0
        0x7f0401b1
        0x7f0401b2
        0x7f0401f9
        0x7f0401fb
        0x7f0401fc
        0x7f0401fd
        0x7f0401fe
        0x7f0401ff
        0x7f040200
        0x7f040201
        0x7f040202
    .end array-data

    :array_23
    .array-data 4
        0x1010000
        0x10100da
        0x7f04016d
        0x7f04016e
        0x7f0401ef
    .end array-data

    :array_24
    .array-data 4
        0x10100d4
        0x7f040034
        0x7f040035
    .end array-data

    :array_25
    .array-data 4
        0x10100d0
        0x10100f2
        0x10100f3
    .end array-data
.end method

.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
